Assignment1.py'nin başına yazdığım açıklamayı buraya da ekliyorum.

# I implemented 2 types of rotation.
# Rotation using your mouse with left click, and Rotation over time.
# Please do right click to change between them.
# I also implemented Zoom-in,Zoom-out option with your mouse wheel.
# Those features made me change the code and the objects a bit, sorry if this is not allowed.  
# I also tested the transformation stack, but did not use for this assignment since I am not translating one by one.

