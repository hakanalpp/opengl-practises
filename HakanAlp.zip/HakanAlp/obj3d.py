# CENG 487 Assignment#1 by
# Hakan Alp
# StudentId: 250201056
# October 2021

class Object3d:
    def __init__(self, *args):
        if(len(args) == 0): # Set default as unit vector
            self.vertices = []
        elif (len(args) == 1):
            self.vertices = args[0]
        elif (len(args) > 1):
            self.vertices = [i for i in args]
        self.transformations = []
        
    def addVertice(self, vertice):
        self.vertices.append(vertice)
    
    def addTransformation(self, transformation):
        self.transformations.append(transformation)